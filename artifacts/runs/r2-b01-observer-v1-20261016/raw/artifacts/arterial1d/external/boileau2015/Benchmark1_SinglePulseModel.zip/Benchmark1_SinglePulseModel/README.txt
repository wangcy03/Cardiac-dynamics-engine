A benchmark study of numerical schemes for one-dimensional arterial blood flow modelling
"Etienne Boileau, Perumal Nithiarasu, Pablo J. Blanco, Lucas O. Muller, Fredrik Eikeland Fossan, Leif Rune Hellevik,"
"Wouter P. Donders, Wouter Huberts, Marie Willemet, Jordi Alastruey"
Int. J. Numer. Meth. Biomed. Engng. 2015

Refer to Table I-II and Equation (14) of the above-cited article.
All files are tab or space separated.

Files in this data supplement:

In NumData:

"Filename: X_Y.txt, with X={DCG,LCG,FEM,FVM,McC,STM}, Y={inviscid,viscous}"
col 1: distance [m]
"col 2 to 9: pressure [kPa] for t={0.1,0.3,0.5,0.7,0.9,1.1,1.3,1.5} [s]"
